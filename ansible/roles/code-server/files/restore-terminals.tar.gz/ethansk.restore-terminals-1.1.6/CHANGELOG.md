# Change Log

## 1.1.6

- Added ability to prevent commands running, just pastes them there, as per [this feature request](https://github.com/EthanSK/restore-terminals-vscode/issues/11#issuecomment-834582672).

## [Unreleased]

- Initial release
